# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#
#   
# The <code>Math</code> module contains module functions for basic
# trigonometric and transcendental functions. See class
# <code>Float</code> for a list of constants that
# define Ruby's floating point accuracy.
#     
# 
# 
module Math
  PI = 'rb_float_new(M_PI)'
  PI = 'rb_float_new(atan(1.0)*4.0)'
  E = 'rb_float_new(M_E)'
  E = 'rb_float_new(exp(1.0))'
  #     Math.acos(x)    => float
  #
  #
  # Computes the arc cosine of <i>x</i>. Returns 0..PI.
  #
  #
  def self.acos(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.acosh(x)    => float
  #
  #
  # Computes the inverse hyperbolic cosine of <i>x</i>.
  #
  #
  def self.acosh(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.asin(x)    => float
  #
  #
  # Computes the arc sine of <i>x</i>. Returns -{PI/2} .. {PI/2}.
  #
  #
  def self.asin(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.asinh(x)    => float
  #
  #
  # Computes the inverse hyperbolic sine of <i>x</i>.
  #
  #
  def self.asinh(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.atan(x)    => float
  #
  #
  # Computes the arc tangent of <i>x</i>. Returns -{PI/2} .. {PI/2}.
  #
  #
  def self.atan(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.atan2(y, x)  => float
  #
  #
  # Computes the arc tangent given <i>y</i> and <i>x</i>. Returns
  # -PI..PI.
  #
  #
  #
  def self.atan2(y, x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.atanh(x)    => float
  #
  #
  # Computes the inverse hyperbolic tangent of <i>x</i>.
  #
  #
  def self.atanh(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.cos(x)    => float
  #
  #
  # Computes the cosine of <i>x</i> (expressed in radians). Returns
  # -1..1.
  #
  #
  def self.cos(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.cosh(x)    => float
  #
  #
  # Computes the hyperbolic cosine of <i>x</i> (expressed in radians).
  #
  #
  def self.cosh(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.erf(x)  => float
  #
  #
  # Calculates the error function of x.
  #
  #
  def self.erf(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.erfc(x)  => float
  #
  #
  # Calculates the complementary error function of x.
  #
  #
  def self.erfc(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.exp(x)    => float
  #
  #
  # Returns e**x.
  #
  #
  def self.exp(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.frexp(numeric)    => [ fraction, exponent ]
  #
  #
  # Returns a two-element array containing the normalized fraction (a
  # <code>Float</code>) and exponent (a <code>Fixnum</code>) of
  # <i>numeric</i>.
  #
  #    fraction, exponent = Math.frexp(1234)   #=> [0.6025390625, 11]
  #    fraction * 2**exponent                  #=> 1234.0
  #
  #
  def self.frexp(numeric)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.hypot(x, y)    => float
  #
  #
  # Returns sqrt(x**2 + y**2), the hypotenuse of a right-angled triangle
  # with sides <i>x</i> and <i>y</i>.
  #
  #    Math.hypot(3, 4)   #=> 5.0
  #
  #
  def self.hypot(x, y)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.ldexp(flt, int) -> float
  #
  #
  # Returns the value of <i>flt</i>*(2**<i>int</i>).
  #
  #    fraction, exponent = Math.frexp(1234)
  #    Math.ldexp(fraction, exponent)   #=> 1234.0
  #
  #
  def self.ldexp(flt, int)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.log(numeric)    => float
  #
  #
  # Returns the natural logarithm of <i>numeric</i>.
  #
  #
  def self.log(numeric)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.log10(numeric)    => float
  #
  #
  # Returns the base 10 logarithm of <i>numeric</i>.
  #
  #
  def self.log10(numeric)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.sin(x)    => float
  #
  #
  # Computes the sine of <i>x</i> (expressed in radians). Returns
  # -1..1.
  #
  #
  def self.sin(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.sinh(x)    => float
  #
  #
  # Computes the hyperbolic sine of <i>x</i> (expressed in
  # radians).
  #
  #
  def self.sinh(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.sqrt(numeric)    => float
  #
  #
  # Returns the non-negative square root of <i>numeric</i>.
  #
  #
  def self.sqrt(numeric)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.tan(x)    => float
  #
  #
  # Returns the tangent of <i>x</i> (expressed in radians).
  #
  #
  def self.tan(x)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Math.tanh()    => float
  #
  #
  # Computes the hyperbolic tangent of <i>x</i> (expressed in
  # radians).
  #
  #
  def self.tanh
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
