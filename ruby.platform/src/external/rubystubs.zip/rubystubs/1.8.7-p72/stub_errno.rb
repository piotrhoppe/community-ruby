# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#
#   
# Ruby exception objects are subclasses of <code>Exception</code>.
# However, operating systems typically report errors using plain
# integers. Module <code>Errno</code> is created dynamically to map
# these operating system errors to Ruby classes, with each error
# number generating its own subclass of <code>SystemCallError</code>.
# As the subclass is created in module <code>Errno</code>, its name
# will start <code>Errno::</code>.
#    
# The names of the <code>Errno::</code> classes depend on
# the environment in which Ruby runs. On a typical Unix or Windows
# platform, there are <code>Errno</code> classes such as
# <code>Errno::EACCES</code>, <code>Errno::EAGAIN</code>,
# <code>Errno::EINTR</code>, and so on.
#    
# The integer operating system error number corresponding to a
# particular error is available as the class constant
# <code>Errno::</code><em>error</em><code>::Errno</code>.
#    
#    Errno::EACCES::Errno   #=> 13
#    Errno::EAGAIN::Errno   #=> 11
#    Errno::EINTR::Errno    #=> 4
#    
# The full list of operating system errors on your particular platform
# are available as the constants of <code>Errno</code>.
#   
#    Errno.constants   #=> E2BIG, EACCES, EADDRINUSE, EADDRNOTAVAIL, ...
# 
module Errno

end
