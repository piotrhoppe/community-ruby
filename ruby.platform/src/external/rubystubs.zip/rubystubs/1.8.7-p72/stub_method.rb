# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#

class Method
  #     meth == other_meth  => true or false
  #
  #
  # Two method objects are equal if that are bound to the same
  # object and contain the same body.
  #
  #
  #
  def ==
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.call(args, ...)    => obj
  #     meth[args, ...]         => obj
  #
  #
  # Invokes the <i>meth</i> with the specified arguments, returning the
  # method's return value.
  #
  #    m = 12.method("+")
  #    m.call(3)    #=> 15
  #    m.call(20)   #=> 32
  #
  #
  def call(args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.arity    => fixnum
  #
  #
  # Returns an indication of the number of arguments accepted by a
  # method. Returns a nonnegative integer for methods that take a fixed
  # number of arguments. For Ruby methods that take a variable number of
  # arguments, returns -n-1, where n is the number of required
  # arguments. For methods written in C, returns -1 if the call takes a
  # variable number of arguments.
  #
  #    class C
  #      def one;    end
  #      def two(a); end
  #      def three(*a);  end
  #      def four(a, b); end
  #      def five(a, b, *c);    end
  #      def six(a, b, *c, &d); end
  #    end
  #    c = C.new
  #    c.method(:one).arity     #=> 0
  #    c.method(:two).arity     #=> 1
  #    c.method(:three).arity   #=> -1
  #    c.method(:four).arity    #=> 2
  #    c.method(:five).arity    #=> -3
  #    c.method(:six).arity     #=> -3
  #
  #    "cat".method(:size).arity      #=> 0
  #    "cat".method(:replace).arity   #=> 1
  #    "cat".method(:squeeze).arity   #=> -1
  #    "cat".method(:count).arity     #=> -1
  #
  #
  def arity
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.call(args, ...)    => obj
  #     meth[args, ...]         => obj
  #
  #
  # Invokes the <i>meth</i> with the specified arguments, returning the
  # method's return value.
  #
  #    m = 12.method("+")
  #    m.call(3)    #=> 15
  #    m.call(20)   #=> 32
  #
  #
  def call(args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #
  # MISSING: documentation
  #
  #
  def clone
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.to_s      =>  string
  #     meth.inspect   =>  string
  #
  #
  # Show the name of the underlying method.
  #
  #   "cat".method(:count).inspect   #=> "#<Method: String#count>"
  #
  #
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.name    => string
  #
  #
  # Returns the name of the method.
  #
  #
  def name
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.owner    => class_or_module
  #
  #
  # Returns the class or module that defines the method.
  #
  #
  def owner
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.receiver    => object
  #
  #
  # Returns the bound receiver of the method object.
  #
  #
  def receiver
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.to_proc    => prc
  #
  #
  # Returns a <code>Proc</code> object corresponding to this method.
  #
  #
  def to_proc
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.to_s      =>  string
  #     meth.inspect   =>  string
  #
  #
  # Show the name of the underlying method.
  #
  #   "cat".method(:count).inspect   #=> "#<Method: String#count>"
  #
  #
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     meth.unbind    => unbound_method
  #
  #
  # Dissociates <i>meth</i> from it's current receiver. The resulting
  # <code>UnboundMethod</code> can subsequently be bound to a new object
  # of the same class (see <code>UnboundMethod</code>).
  #
  #
  def unbind
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
