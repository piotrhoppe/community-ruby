# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#
#   
# The global value <code>false</code> is the only instance of class
# <code>FalseClass</code> and represents a logically false value in
# boolean expressions. The class provides operators allowing
# <code>false</code> to participate correctly in logical expressions.
#    
# 
class FalseClass
  #     false & obj   => false
  #     nil & obj     => false
  #
  #
  # And---Returns <code>false</code>. <i>obj</i> is always
  # evaluated as it is the argument to a method call---there is no
  # short-circuit evaluation in this case.
  #
  #
  def &
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     false ^ obj    => true or false
  #     nil   ^ obj    => true or false
  #
  #
  # Exclusive Or---If <i>obj</i> is <code>nil</code> or
  # <code>false</code>, returns <code>false</code>; otherwise, returns
  # <code>true</code>.
  #
  #
  #
  def ^
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     false | obj   =>   true or false
  #     nil   | obj   =>   true or false
  #
  #
  # Or---Returns <code>false</code> if <i>obj</i> is
  # <code>nil</code> or <code>false</code>; <code>true</code> otherwise.
  #
  #
  def |
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     false.to_s   =>  "false"
  #
  #
  # 'nuf said...
  #
  #
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
