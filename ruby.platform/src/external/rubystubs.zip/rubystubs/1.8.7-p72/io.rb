# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#

class IO
  #
  # =begin
  # --- IO#ready?
  # returns non-nil if input available without blocking, or nil.
  # =end
  #
  def ready?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #
  # =begin
  # --- IO#wait([timeout])
  # waits until input available or timed out and returns self, or nil
  # when EOF reached.
  # =end
  #
  def wait(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
