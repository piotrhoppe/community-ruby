# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#

class DBM
  include Enumerable
  READER = 'INT2FIX(O_RDONLY|RUBY_DBM_RW_BIT)'
  WRITER = 'INT2FIX(O_RDWR|RUBY_DBM_RW_BIT)'
  WRCREAT = 'INT2FIX(O_RDWR|O_CREAT|RUBY_DBM_RW_BIT)'
  NEWDB = 'INT2FIX(O_RDWR|O_CREAT|O_TRUNC|RUBY_DBM_RW_BIT)'
  VERSION = 'rb_str_new2(DB_VERSION_STRING)'
  VERSION = 'rb_str_new2("unknown")'

end

class DBMError < StandardError

end
