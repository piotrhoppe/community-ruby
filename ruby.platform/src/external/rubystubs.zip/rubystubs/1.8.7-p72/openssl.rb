# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.7-p72"
# Generator version: 1.0
#

#
#   
# OSSL library init
# 
module OpenSSL
  VERSION = 'rb_str_new2(OSSL_VERSION)'
  OPENSSL_VERSION = 'rb_str_new2(OPENSSL_VERSION_TEXT)'
  OPENSSL_VERSION_NUMBER = 'INT2NUM(OPENSSL_VERSION_NUMBER)'
  #     OpenSSL.debug = boolean -> boolean
  #
  #
  # Turns on or off CRYPTO_MEM_CHECK.
  # Also shows some debugging message on stderr.
  #
  def self.debug=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #
  # call-seq:
  #  OpenSSL.debug -> true | false
  #
  def self.debug
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     OpenSSL.errors -> [String...]
  #
  #
  # See any remaining errors held in queue.
  #
  # Any errors you see here are probably due to a bug in ruby's OpenSSL implementation.
  #
  def self.errors
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


  module ASN1
    UNIVERSAL_TAG_NAME = ary

    class ASN1Data

    end

    class ASN1Error < eOSSLError

    end

    class Constructive < OpenSSL::ASN1::ASN1Data
      include Enumerable

    end

    class Primitive < OpenSSL::ASN1::ASN1Data

    end

  end

  class BN
    #
    # call-seq:
    #   bn1 / bn2 => [result, remainder]
    #
    def /(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #
    # call-seq:
    #   bn.bit_set?(bit) => true | false
    #
    def bit_set?(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     BN.generate_prime(bits, [, safe [, add [, rem]]]) => bn
    #
    #
    # === Parameters
    # * +bits+ - integer
    # * +safe+ - boolean
    # * +add+ - BN
    # * +rem+ - BN
    #
    def self.generate_prime(bits, safe, add, rem)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #
    # call-seq:
    #   BN.new => aBN
    #   BN.new(bn) => aBN
    #   BN.new(string) => aBN
    #   BN.new(string, 0 | 2 | 10 | 16) => aBN
    #
    def self.new(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     bn.prime? => true | false
    #     bn.prime?(checks) => true | false
    #
    #
    # === Parameters
    # * +checks+ - integer
    #
    def prime?(checks)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     bn.prime_fasttest? => true | false
    #     bn.prime_fasttest?(checks) => true | false
    #     bn.prime_fasttest?(checks, trial_div) => true | false
    #
    #
    # === Parameters
    # * +checks+ - integer
    # * +trial_div+ - boolean
    #
    def prime_fasttest?(checks, trial_div)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     bn.prime_fasttest? => true | false
    #     bn.prime_fasttest?(checks) => true | false
    #     bn.prime_fasttest?(checks, trial_div) => true | false
    #
    #
    # === Parameters
    # * +checks+ - integer
    # * +trial_div+ - boolean
    #
    def prime_fasttest?(checks)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #
    # call-seq:
    #   bn.to_i => integer
    #
    def to_i
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # Alias for #to_i
    def to_int
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     bn.to_s => string
    #     bn.to_s(base) => string
    #
    #
    # === Parameters
    # * +base+ - integer
    # * * Valid values:
    # * * * 0 - MPI
    # * * * 2 - binary
    # * * * 10 - the default
    # * * * 16 - hex
    #
    def to_s(base)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  class BNError < eOSSLError

  end

  class Cipher
    #     cipher << data -> string
    #
    #
    # === Parameters
    # +data+ is a nonempty string.
    #
    # This method is deprecated and not available in 1.9.x or later.
    #
    def <<
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.block_size -> integer
    #
    #
    #
    def block_size
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     Cipher.ciphers -> array[string...]
    #
    #
    # Returns the names of all available ciphers in an array.
    #
    def self.ciphers
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.decrypt -> self
    #
    #
    # Make sure to call .encrypt or .decrypt before using any of the following methods:
    # * [key=, iv=, random_key, random_iv, pkcs5_keyivgen]
    #
    # Internally calls EVP_CipherInit_ex(ctx, NULL, NULL, NULL, NULL, 0).
    #
    def decrypt
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.encrypt -> self
    #
    #
    # Make sure to call .encrypt or .decrypt before using any of the following methods:
    # * [key=, iv=, random_key, random_iv, pkcs5_keyivgen]
    #
    # Internally calls EVP_CipherInit_ex(ctx, NULL, NULL, NULL, NULL, 1).
    #
    def encrypt
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.final -> aString
    #
    #
    # Returns the remaining data held in the cipher object.  Further calls to update() or final() will return garbage.
    #
    # See EVP_CipherFinal_ex for further information.
    #
    def final
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.iv = string -> string
    #
    #
    # Sets the cipher iv.
    #
    # Only call this method after calling cipher.encrypt or cipher.decrypt.
    #
    def iv=
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.iv_length -> integer
    #
    #
    #
    def iv_len
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.key = string -> string
    #
    #
    # Sets the cipher key.
    #
    # Only call this method after calling cipher.encrypt or cipher.decrypt.
    #
    def key=
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.key_length = integer -> integer
    #
    #
    # Sets the key length of the cipher.  If the cipher is a fixed length cipher then attempting to set the key
    # length to any value other than the fixed value is an error.
    #
    # Under normal circumstances you do not need to call this method (and probably shouldn't).
    #
    # See EVP_CIPHER_CTX_set_key_length for further information.
    #
    def key_len=
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.key_length -> integer
    #
    #
    #
    def key_len
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.name -> string
    #
    #
    # Returns the name of the cipher which may differ slightly from the original name provided.
    #
    def name
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     Cipher.new(string) -> cipher
    #
    #
    # The string must contain a valid cipher name like "AES-128-CBC" or "3DES".
    #
    # A list of cipher names is available by calling OpenSSL::Cipher.ciphers.
    #
    def self.new(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.padding = integer -> integer
    #
    #
    # Enables or disables padding. By default encryption operations are padded using standard block padding and the
    # padding is checked and removed when decrypting. If the pad parameter is zero then no padding is performed, the
    # total amount of data encrypted or decrypted must then be a multiple of the block size or an error will occur.
    #
    # See EVP_CIPHER_CTX_set_padding for further information.
    #
    def padding=
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.pkcs5_keyivgen(pass [, salt [, iterations [, digest]]] ) -> nil
    #
    #
    # Generates and sets the key/iv based on a password.
    #
    # WARNING: This method is only PKCS5 v1.5 compliant when using RC2, RC4-40, or DES
    # with MD5 or SHA1.  Using anything else (like AES) will generate the key/iv using an
    # OpenSSL specific method.  Use a PKCS5 v2 key generation method instead.
    #
    # === Parameters
    # +salt+ must be an 8 byte string if provided.
    # +iterations+ is a integer with a default of 2048.
    # +digest+ is a Digest object that defaults to 'MD5'
    #
    # A minimum of 1000 iterations is recommended.
    #
    #
    def pkcs5_keyivgen(pass, salt, iterations, digest )
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.reset -> self
    #
    #
    # Internally calls EVP_CipherInit_ex(ctx, NULL, NULL, NULL, NULL, -1).
    #
    def reset
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     cipher.update(data [, buffer]) -> string or buffer
    #
    #
    # === Parameters
    # +data+ is a nonempty string.
    # +buffer+ is an optional string to store the result.
    #
    def update(data, buffer)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


    class CipherError < eOSSLError

    end

  end

  class HMAC
    # Alias for #update
    def <<(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     HMAC.digest(digest, key, data) -> aString
    #
    #
    #
    def self.digest(digest, key, data)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     hmac.digest -> aString
    #
    #
    #
    def digest
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     HMAC.digest(digest, key, data) -> aString
    #
    #
    #
    def self.digest(digest, key, data)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     hmac.hexdigest -> aString
    #
    #
    #
    def hexdigest
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # Alias for #hexdigest
    def inspect
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     HMAC.new(key, digest) -> hmac
    #
    #
    #
    def self.new(key, digest)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     hmac.reset -> self
    #
    #
    #
    def reset
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # Alias for #hexdigest
    def to_s
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     hmac.update(string) -> self
    #
    #
    #
    def update(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  class HMACError < eOSSLError

  end

  class OpenSSLError < StandardError

  end

  module PKey

    class DH < cPKey
      #     dh.compute_key(pub_bn) -> aString
      #
      #
      # === Parameters
      # * +pub_bn+ is a OpenSSL::BN.
      #
      # Returns aString containing a shared secret computed from the other parties public value.
      #
      # See DH_compute_key() for further information.
      #
      #
      def compute_key(pub_bn)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.to_pem -> aString
      #
      #
      #
      def export
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     DH.generate(size [, generator]) -> dh
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.  Keys smaller than 1024 should be considered insecure.
      # * +generator+ is a small number > 1, typically 2 or 5.
      #
      #
      def self.generate(size, generator)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.generate_key -> self
      #
      #
      #
      def generate_key!
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     DH.new([size [, generator] | string]) -> dh
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.  Keys smaller than 1024 should be considered insecure.
      # * +generator+ is a small number > 1, typically 2 or 5.
      # * +string+ contains the DER or PEM encoded key.
      #
      # === Examples
      # * DH.new -> dh
      # * DH.new(1024) -> dh
      # * DH.new(1024, 5) -> dh
      # * DH.new(File.read('key.pem')) -> dh
      #
      def self.new(size, generator_or_string)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.params -> hash
      #
      #
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      #
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.check_params -> true | false
      #
      #
      #
      def params_ok?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.private? -> true | false
      #
      #
      #
      def private?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.public? -> true | false
      #
      #
      #
      def public?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.public_key -> aDH
      #
      #
      # Makes new instance DH PUBLIC_KEY from PRIVATE_KEY
      #
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.to_der -> aString
      #
      #
      #
      def to_der
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_pem
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_s
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dh.to_text -> aString
      #
      #
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      #
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class DHError < ePKeyError

    end

    class DSA < cPKey
      #     dsa.to_pem([cipher, password]) -> aString
      #
      #
      # === Parameters
      # +cipher+ is an OpenSSL::Cipher.
      # +password+ is a string containing your password.
      #
      # === Examples
      # * DSA.to_pem -> aString
      # * DSA.to_pem(cipher, 'mypassword') -> aString
      #
      #
      def to_pem(cipher, password)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     DSA.generate(size) -> dsa
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.
      #
      #
      def self.generate(size)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     DSA.new([size | string [, pass]) -> dsa
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.
      # * +string+ contains a DER or PEM encoded key.
      # * +pass+ is a string that contains a optional password.
      #
      # === Examples
      # * DSA.new -> dsa
      # * DSA.new(1024) -> dsa
      # * DSA.new(File.read('dsa.pem')) -> dsa
      # * DSA.new(File.read('dsa.pem'), 'mypassword') -> dsa
      #
      #
      def self.new(size_or_string, pass)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.params -> hash
      #
      #
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      #
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.private? -> true | false
      #
      #
      #
      def private?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.public? -> true | false
      #
      #
      #
      def public?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.public_key -> aDSA
      #
      #
      # Makes new instance DSA PUBLIC_KEY from PRIVATE_KEY
      #
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.syssign(string) -> aString
      #
      #
      #
      def syssign(string)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.sysverify(digest, sig) -> true | false
      #
      #
      #
      def sysverify(digest, sig)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.to_der -> aString
      #
      #
      #
      def to_der
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_pem(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_s(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     dsa.to_text -> aString
      #
      #
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      #
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class DSAError < ePKeyError

    end

    class EC < cPKey
      NAMED_CURVE = 'ULONG2NUM(OPENSSL_EC_NAMED_CURVE)'
      #     EC.builtin_curves => [[name, comment], ...]
      #
      # See the OpenSSL documentation for EC_builtin_curves()
      #
      def self.builtin_curves
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.check_key   => true
      #
      #
      # Raises an exception if the key is invalid.
      #
      # See the OpenSSL documentation for EC_KEY_check_key()
      #
      def check_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.dh_compute_key(pubkey)   => String
      #
      #
      # See the OpenSSL documentation for ECDH_compute_key()
      #
      def dh_compute_key(pubkey)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.dsa_sign_asn1(data)   => String
      #
      #
      # See the OpenSSL documentation for ECDSA_sign()
      #
      def dsa_sign_asn1(data)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.dsa_verify(data, sig)   => true or false
      #
      #
      # See the OpenSSL documentation for ECDSA_verify()
      #
      def dsa_verify(data, sig)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.generate_key   => self
      #
      #
      # See the OpenSSL documentation for EC_KEY_generate_key()
      #
      def generate_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.group = group   => group
      #
      #
      # Returns the same object passed, not the group object associated with the key.
      # If you wish to access the group object tied to the key call key.group after setting
      # the group.
      #
      # Setting the group will immediately destroy any previously assigned group object.
      # The group is internally copied by OpenSSL.  Modifying the original group after
      # assignment will not effect the internal key structure.
      # (your changes may be lost).  BE CAREFUL.
      #
      # EC_KEY_set_group calls EC_GROUP_free(key->group) then EC_GROUP_dup(), not EC_GROUP_copy.
      # This documentation is accurate for OpenSSL 0.9.8b.
      #
      def group=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.group   => group
      #
      #
      # Returns a constant <code>OpenSSL::EC::Group</code> that is tied to the key.
      # Modifying the returned group can make the key invalid.
      #
      def group
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     OpenSSL::PKey::EC.new()
      #     OpenSSL::PKey::EC.new(ec_key)
      #     OpenSSL::PKey::EC.new(ec_group)
      #     OpenSSL::PKey::EC.new("secp112r1")
      #     OpenSSL::PKey::EC.new(pem_string)
      #     OpenSSL::PKey::EC.new(der_string)
      #
      # See the OpenSSL documentation for:
      #    EC_KEY_*
      #
      def self.new(der_string)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     OpenSSL::PKey::EC.new()
      #     OpenSSL::PKey::EC.new(ec_key)
      #     OpenSSL::PKey::EC.new(ec_group)
      #     OpenSSL::PKey::EC.new("secp112r1")
      #     OpenSSL::PKey::EC.new(pem_string)
      #     OpenSSL::PKey::EC.new(der_string)
      #
      # See the OpenSSL documentation for:
      #    EC_KEY_*
      #
      def self.new(key)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     OpenSSL::PKey::EC.new()
      #     OpenSSL::PKey::EC.new(ec_key)
      #     OpenSSL::PKey::EC.new(ec_group)
      #     OpenSSL::PKey::EC.new("secp112r1")
      #     OpenSSL::PKey::EC.new(pem_string)
      #     OpenSSL::PKey::EC.new(der_string)
      #
      # See the OpenSSL documentation for:
      #    EC_KEY_*
      #
      def self.new(ec_group)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     OpenSSL::PKey::EC.new()
      #     OpenSSL::PKey::EC.new(ec_key)
      #     OpenSSL::PKey::EC.new(ec_group)
      #     OpenSSL::PKey::EC.new("secp112r1")
      #     OpenSSL::PKey::EC.new(pem_string)
      #     OpenSSL::PKey::EC.new(der_string)
      #
      # See the OpenSSL documentation for:
      #    EC_KEY_*
      #
      def self.new(ec_key)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     OpenSSL::PKey::EC.new()
      #     OpenSSL::PKey::EC.new(ec_key)
      #     OpenSSL::PKey::EC.new(ec_group)
      #     OpenSSL::PKey::EC.new("secp112r1")
      #     OpenSSL::PKey::EC.new(pem_string)
      #     OpenSSL::PKey::EC.new(der_string)
      #
      # See the OpenSSL documentation for:
      #    EC_KEY_*
      #
      def self.new(pem_string)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.private_key = openssl_bn
      #
      #
      # See the OpenSSL documentation for EC_KEY_set_private_key()
      #
      def private_key=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.private_key? => true or false
      #
      #
      # Both public_key? and private_key? may return false at the same time unlike other PKey classes.
      #
      def private_key?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.private_key   => OpenSSL::BN
      #
      #
      # See the OpenSSL documentation for EC_KEY_get0_private_key()
      #
      def private_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.public_key = ec_point
      #
      #
      # See the OpenSSL documentation for EC_KEY_set_public_key()
      #
      def public_key=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.public_key? => true or false
      #
      #
      # Both public_key? and private_key? may return false at the same time unlike other PKey classes.
      #
      def public_key?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.public_key   => OpenSSL::PKey::EC::Point
      #
      #
      # See the OpenSSL documentation for EC_KEY_get0_public_key()
      #
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.to_der   => String
      #
      #
      # See the OpenSSL documentation for i2d_ECPrivateKey_bio()
      #
      def to_der
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.to_pem   => String
      #
      #
      # See the OpenSSL documentation for PEM_write_bio_ECPrivateKey()
      #
      def to_pem
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     key.to_text   => String
      #
      #
      # See the OpenSSL documentation for EC_KEY_print()
      #
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


      class Group
        # Alias for #eql?
        def ==(p1)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.asn1_flag = Fixnum   => Fixnum
        #
        # See the OpenSSL documentation for EC_GROUP_set_asn1_flag()
        #
        def asn1_flag=
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.asn1_flag  => Fixnum
        #
        # See the OpenSSL documentation for EC_GROUP_get_asn1_flag()
        #
        def asn1_flag
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.get_cofactor   => cofactor_bn
        #
        # See the OpenSSL documentation for EC_GROUP_get_cofactor()
        #
        def cofactor
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.curve_name  => String
        #
        # See the OpenSSL documentation for EC_GROUP_get_curve_name()
        #
        def curve_name
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.degree   => Fixnum
        #
        # See the OpenSSL documentation for EC_GROUP_get_degree()
        #
        def degree
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group1 == group2   => true | false
        #
        #
        def eql?
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.generator   => ec_point
        #
        # See the OpenSSL documentation for EC_GROUP_get0_generator()
        #
        def generator
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gFp_nist)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gFp_simple)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(der_file)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(pem_file)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(der_string)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gF2m, bignum_p, bignum_a, bignum_b)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gFp_mult)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gF2m_simple)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(ec_group)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(key)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(pem_string)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Group.new("secp112r1")
        #     OpenSSL::PKey::EC::Group.new(ec_group)
        #     OpenSSL::PKey::EC::Group.new(pem_string)
        #     OpenSSL::PKey::EC::Group.new(der_string)
        #     OpenSSL::PKey::EC::Group.new(pem_file)
        #     OpenSSL::PKey::EC::Group.new(der_file)
        #     OpenSSL::PKey::EC::Group.new(:GFp_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp_mult)
        #     OpenSSL::PKey::EC::Group.new(:GFp_nist)
        #     OpenSSL::PKey::EC::Group.new(:GF2m_simple)
        #     OpenSSL::PKey::EC::Group.new(:GFp, bignum_p, bignum_a, bignum_b)
        #     OpenSSL::PKey::EC::Group.new(:GF2m, bignum_p, bignum_a, bignum_b)
        #
        # See the OpenSSL documentation for EC_GROUP_*
        #
        def self.new(gFp, bignum_p, bignum_a, bignum_b)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.get_order   => order_bn
        #
        # See the OpenSSL documentation for EC_GROUP_get_order()
        #
        def order
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.point_conversion_form = form => form
        #
        # See the OpenSSL documentation for EC_GROUP_set_point_conversion_form()
        #
        def point_conversion_form=
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.point_conversion_form  => :uncompressed | :compressed | :hybrid
        #
        # See the OpenSSL documentation for EC_GROUP_get_point_conversion_form()
        #
        def point_conversion_form
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.seed = seed  => seed
        #
        # See the OpenSSL documentation for EC_GROUP_set_seed()
        #
        def seed=
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.seed   => String or nil
        #
        # See the OpenSSL documentation for EC_GROUP_get0_seed()
        #
        def seed
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.set_generator(generator, order, cofactor)   => self
        #
        # See the OpenSSL documentation for EC_GROUP_set_generator()
        #
        def set_generator(generator, order, cofactor)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.to_der   => String
        #
        # See the OpenSSL documentation for i2d_ECPKParameters_bio()
        #
        def to_der
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.to_pem   => String
        #
        # See the OpenSSL documentation for PEM_write_bio_ECPKParameters()
        #
        def to_pem
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     group.to_text   => String
        #
        # See the OpenSSL documentation for ECPKParameters_print()
        #
        def to_text
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end


        class Error < eOSSLError

        end

      end

      class Point
        # Alias for #eql?
        def ==(p1)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point1 == point2 => true | false
        #
        #
        #
        def eql?
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.infinity? => true | false
        #
        #
        #
        def infinity?
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.invert! => self
        #
        #
        #
        def invert!
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.make_affine! => self
        #
        #
        #
        def make_affine!
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Point.new(point)
        #     OpenSSL::PKey::EC::Point.new(group)
        #     OpenSSL::PKey::EC::Point.new(group, bn)
        #
        #
        # See the OpenSSL documentation for EC_POINT_*
        #
        def self.new(point)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Point.new(point)
        #     OpenSSL::PKey::EC::Point.new(group)
        #     OpenSSL::PKey::EC::Point.new(group, bn)
        #
        #
        # See the OpenSSL documentation for EC_POINT_*
        #
        def self.new(group, bn)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     OpenSSL::PKey::EC::Point.new(point)
        #     OpenSSL::PKey::EC::Point.new(group)
        #     OpenSSL::PKey::EC::Point.new(group, bn)
        #
        #
        # See the OpenSSL documentation for EC_POINT_*
        #
        def self.new(group)
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.on_curve? => true | false
        #
        #
        #
        def on_curve?
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.set_to_infinity! => self
        #
        #
        #
        def set_to_infinity!
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end

        #     point.to_bn   => OpenSSL::BN
        #
        #
        # See the OpenSSL documentation for EC_POINT_point2bn()
        #
        def to_bn
          # This is just a stub for a builtin Ruby method.
          # See the top of this file for more info.
        end


        class Error < eOSSLError

        end

      end

    end

    class ECError < ePKeyError

    end

    class PKey

    end

    class PKeyError < eOSSLError

    end

    class RSA < cPKey
      #     rsa.to_pem([cipher, pass]) -> aString
      #
      #
      # === Parameters
      # * +cipher+ is a Cipher object.
      # * +pass+ is a string.
      #
      # === Examples
      # * rsa.to_pem -> aString
      # * rsa.to_pem(cipher, pass) -> aString
      #
      def to_pem(cipher, pass)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     RSA.generate(size [, exponent]) -> rsa
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.  Keys smaller than 1024 should be considered insecure.
      # * +exponent+ is an odd number normally 3, 17, or 65537.
      #
      #
      def self.generate(size, exponent)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     RSA.new([size | encoded_key] [, pass]) -> rsa
      #
      #
      # === Parameters
      # * +size+ is an integer representing the desired key size.
      # * +encoded_key+ is a string containing PEM or DER encoded key.
      # * +pass+ is an optional string with the password to decrypt the encoded key.
      #
      # === Examples
      # * RSA.new(2048) -> rsa
      # * RSA.new(File.read("rsa.pem")) -> rsa
      # * RSA.new(File.read("rsa.pem"), "mypassword") -> rsa
      #
      def self.new(size_or_encoded_key, pass)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.params -> hash
      #
      #
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      #
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.private? -> true | false
      #
      #
      #
      def private?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.private_decrypt(string [, padding]) -> aString
      #
      #
      #
      def private_decrypt(string, padding)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.private_encrypt(string [, padding]) -> aString
      #
      #
      #
      def private_encrypt(string, padding)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.public? -> true
      #
      #
      # The return value is always true since every private key is also a public key.
      #
      #
      def public?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.public_decrypt(string [, padding]) -> aString
      #
      #
      #
      def public_decrypt(string, padding)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.public_encrypt(string [, padding]) -> aString
      #
      #
      #
      def public_encrypt(string, padding)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.public_key -> aRSA
      #
      #
      # Makes new instance RSA PUBLIC_KEY from PRIVATE_KEY
      #
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.to_der -> aString
      #
      #
      #
      def to_der
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_pem(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      # Alias for #export
      def to_s(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     rsa.to_text -> aString
      #
      #
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (It's up to you)
      #
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class RSAError < ePKeyError

    end

  end

  module Random

    class RandomError < eOSSLError

    end

  end

  module SSL

    class SSLContext
      SESSION_CACHE_OFF = 'LONG2FIX(SSL_SESS_CACHE_OFF)'
      SESSION_CACHE_CLIENT = 'LONG2FIX(SSL_SESS_CACHE_CLIENT)'
      SESSION_CACHE_SERVER = 'LONG2FIX(SSL_SESS_CACHE_SERVER)'
      SESSION_CACHE_BOTH = 'LONG2FIX(SSL_SESS_CACHE_BOTH)'
      SESSION_CACHE_NO_AUTO_CLEAR = 'LONG2FIX(SSL_SESS_CACHE_NO_AUTO_CLEAR)'
      SESSION_CACHE_NO_INTERNAL_LOOKUP = 'LONG2FIX(SSL_SESS_CACHE_NO_INTERNAL_LOOKUP)'
      SESSION_CACHE_NO_INTERNAL_STORE = 'LONG2FIX(SSL_SESS_CACHE_NO_INTERNAL_STORE)'
      SESSION_CACHE_NO_INTERNAL = 'LONG2FIX(SSL_SESS_CACHE_NO_INTERNAL)'
      METHODS = ary
      #
      # call-seq:
      #   ctx.ciphers = "cipher1:cipher2:..."
      #   ctx.ciphers = [name, ...]
      #   ctx.ciphers = [[name, version, bits, alg_bits], ...]
      #
      def ciphers=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ctx.ciphers => [[name, version, bits, alg_bits], ...]
      #
      def ciphers
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.flush_sessions(time | nil) -> self
      #
      #
      #
      def flush_sessions(time_or_nil)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     SSLContext.new => ctx
      #     SSLContext.new(:TLSv1) => ctx
      #     SSLContext.new("SSLv23_client") => ctx
      #
      #
      # You can get a list of valid methods with OpenSSL::SSL::SSLContext::METHODS
      #
      def self.new(key)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_add(session) -> true | false
      #
      #
      #
      def session_add(session)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_cache_mode=(integer) -> integer
      #
      #
      #
      def session_cache_mode=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_cache_mode -> integer
      #
      #
      #
      def session_cache_mode
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_cache_size=(integer) -> integer
      #
      #
      #
      def session_cache_size=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_cache_size -> integer
      #
      #
      #
      def session_cache_size
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_cache_stats -> Hash
      #
      #
      #
      def session_cache_stats
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.session_remove(session) -> true | false
      #
      #
      #
      def session_remove(session)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ctx.setup => Qtrue # first time
      #     ctx.setup => nil # thereafter
      #
      #
      # This method is called automatically when a new SSLSocket is created.
      # Normally you do not need to call this method (unless you are writing an extension in C).
      #
      def setup
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class SSLError < eOSSLError

    end

    class SSLSocket
      #
      # call-seq:
      #   ssl.accept => self
      #
      def accept
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.cert => cert or nil
      #
      def cert
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.cipher => [name, version, bits, alg_bits]
      #
      def cipher
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.connect => self
      #
      def connect
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     SSLSocket.new(io) => aSSLSocket
      #     SSLSocket.new(io, ctx) => aSSLSocket
      #
      #
      # === Parameters
      # * +io+ is a real ruby IO object.  Not an IO like object that responds to read/write.
      # * +ctx+ is an OpenSSLSSL::SSLContext.
      #
      # The OpenSSL::Buffering module provides additional IO methods.
      #
      # This method will freeze the SSLContext if one is provided;
      # however, session management is still allowed in the frozen SSLContext.
      #
      def self.new(io, ctx)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     SSLSocket.new(io) => aSSLSocket
      #     SSLSocket.new(io, ctx) => aSSLSocket
      #
      #
      # === Parameters
      # * +io+ is a real ruby IO object.  Not an IO like object that responds to read/write.
      # * +ctx+ is an OpenSSLSSL::SSLContext.
      #
      # The OpenSSL::Buffering module provides additional IO methods.
      #
      # This method will freeze the SSLContext if one is provided;
      # however, session management is still allowed in the frozen SSLContext.
      #
      def self.new(io)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.peer_cert => cert or nil
      #
      def peer_cert
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.peer_cert_chain => [cert, ...] or nil
      #
      def peer_cert_chain
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.pending => integer
      #
      def pending
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ssl.session = session -> session
      #
      #
      #
      def session=
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ssl.session_reused? -> true | false
      #
      #
      #
      def session_reused?
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.state => string
      #
      def state
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.sysclose => nil
      #
      def sysclose
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ssl.sysread(length) => string
      #     ssl.sysread(length, buffer) => buffer
      #
      #
      # === Parameters
      # * +length+ is a positive integer.
      # * +buffer+ is a string used to store the result.
      #
      def sysread(length)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     ssl.sysread(length) => string
      #     ssl.sysread(length, buffer) => buffer
      #
      #
      # === Parameters
      # * +length+ is a positive integer.
      # * +buffer+ is a string used to store the result.
      #
      def sysread(length, buffer)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #
      # call-seq:
      #   ssl.syswrite(string) => integer
      #
      def syswrite(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Session
      #     session1 == session2 -> boolean
      #
      #
      #
      def ==
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.id -> aString
      #
      #
      # Returns the Session ID.
      #
      def id
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     Session.new(SSLSocket | string) => session
      #
      #
      # === Parameters
      # +SSLSocket+ is an OpenSSL::SSL::SSLSocket
      # +string+ must be a DER or PEM encoded Session.
      #
      def self.new(sslSocket_or_String)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.time -> Time
      #
      #
      #
      def time
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.timeout -> integer
      #
      #
      # How long until the session expires in seconds.
      #
      #
      def timeout
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.to_der -> aString
      #
      #
      # Returns an ASN1 encoded String that contains the Session object.
      #
      def to_der
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.to_pem -> String
      #
      #
      # Returns a PEM encoded String that contains the Session object.
      #
      def to_pem
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #     session.to_text -> String
      #
      #
      # Shows everything in the Session object.
      #
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


      class SessionError < eOSSLError

      end

    end

  end

end
